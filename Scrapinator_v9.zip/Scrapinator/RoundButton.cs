﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

class RoundButton : Button
{
    protected override void OnResize(EventArgs e)
    {
        using (var path = new GraphicsPath())
        {
            path.AddEllipse(new Rectangle(5, 5, this.Width - 3, this.Height - 3));
            this.Region = new Region(path);
        }
        base.OnResize(e);
    }
}