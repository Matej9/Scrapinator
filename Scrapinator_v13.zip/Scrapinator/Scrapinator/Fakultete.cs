﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scrapinator
{
    class Fakultete
    {
        public string MSTID { get; set; }
        public string NAME { get; set; }
        public string CITY { get; set; }
        public string ORGID { get; set; }
        public string RSRID { get; set; }
        public string RSR_MSTID { get; set; }
        public string DIR_LNAME { get; set; }
        public string DIR_FNAME { get; set; }
        public string DIRFUN { get; set; }
        public string regnum { get; set; }
        public string DIRTTLPRE { get; set; }
        public string DIRTTLPOST { get; set; }
    }
}
