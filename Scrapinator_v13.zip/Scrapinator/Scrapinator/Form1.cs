﻿using Newtonsoft.Json;
using ScrapinatorRaziskovalec;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections;


namespace Scrapinator
{
    public partial class Form1 : Form
    {
        public class Posameznik
        {
            public string evd_stevilka = ""; public string naziv = "";
            public string ime = ""; public string priimek = "";
            public string email = ""; public string raz_pod = "";
            public string status = ""; public string tocke = "";
            public string vede = ""; public string podrocja = "";
            public string podpodrocja = ""; public string jeziki = "";
            public string projekti = ""; public string programi = "";
            public string klj_besede = "";
        }
        public class Faculty
        {
            public string ime = ""; public string mesto = "";
            public string odg_oseba = ""; public string naslov = "";
            public string telefon = ""; public string faks = "";
            public string email = ""; public string url = "";
            public string arrs_veda = ""; public string arrs_podrocje = ""; public string arrs_podpodrocje = "";
            public string cerif_veda = ""; public string ceirf_podrocje = "";
            public string corids = ""; public string zaposleni = "";
            public string projekti = ""; public string programi = "";
            public string med_projekti = ""; public string skupine = "";
        }

        List<Raziskovalci> raziskovalci;
        List<Fakultete> fakultete;
        List<Posameznik> posamezniki = new List<Posameznik>();
        List<Faculty> faculties = new List<Faculty>();
        private int sortColumn = -1; //zadnji kliknjen stolpec
        private bool dobljeneFakultete = false;
        private bool start = false, fakultete_start=false;

        public Form1()
        {
            InitializeComponent();
            listRaziskovalcev.Columns[8].Dispose();//skrijem RSRID polje
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Excel files(*.xls)| *.xls|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                if (xlApp == null)
                {
                    MessageBox.Show("Excel is not properly installed!!");
                    return;
                }

                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                Excel.Range formatRange;
                formatRange = xlWorkSheet.get_Range("A:A");
                formatRange.NumberFormat = "@";


                xlWorkSheet.Cells[1, 1] = "EVIDENČNA ŠT.";
                xlWorkSheet.Cells[1, 2] = "NAZIV";
                xlWorkSheet.Cells[1, 3] = "IME";
                xlWorkSheet.Cells[1, 4] = "PRIIMEK";
                xlWorkSheet.Cells[1, 5] = "EMAIL";
                xlWorkSheet.Cells[1, 6] = "RAZISK. PODROČJE";
                xlWorkSheet.Cells[1, 7] = "STATUS";
                xlWorkSheet.Cells[1, 8] = "TOČKE";
                xlWorkSheet.Cells[1, 9] = "VEDE";
                xlWorkSheet.Cells[1, 10] = "PODROČJE";
                xlWorkSheet.Cells[1, 11] = "PODPODROČJE";
                xlWorkSheet.Cells[1, 12] = "JEZIKI";
                xlWorkSheet.Cells[1, 13] = "PROJEKTI";
                xlWorkSheet.Cells[1, 14] = "PROGRAMI";
                xlWorkSheet.Cells[1, 15] = "KLJUČNE BESEDE";

                int vrstica = 1;
                string json = "";
                using (WebClient wc = new WebClient())
                {
                    wc.Encoding = System.Text.Encoding.UTF8;
                    json = wc.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=&country=SI_JSON&entity=org&methodCall=id=3179%20and%20lang=slv");

                }

                raziskovalci = JsonConvert.DeserializeObject<List<Raziskovalci>>(json);

                foreach (EMPLOY raziskovalec in raziskovalci[0].EMPLOY)
                {

                    using (WebClient wc1 = new WebClient())
                    {
                        wc1.Encoding = Encoding.UTF8;
                        json = wc1.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=&country=SI_JSON&entity=rsr&methodCall=id=" + raziskovalec.RSRID + "%20and%20lang=slv");
                    }
                    List<Raziskovalec> raziskovalecObj = JsonConvert.DeserializeObject<List<Raziskovalec>>(json);
                    raziskovalec.ABBREV = raziskovalecObj[0].ABBREV;

                    vrstica++;
                    xlWorkSheet.Cells[vrstica, 1] = raziskovalec.MSTID;
                    xlWorkSheet.Cells[vrstica, 2] = raziskovalec.ABBREV;
                    xlWorkSheet.Cells[vrstica, 3] = raziskovalec.FNAME;
                    xlWorkSheet.Cells[vrstica, 4] = raziskovalec.LNAME;
                    if (raziskovalecObj[0].CONTACT != null)
                        xlWorkSheet.Cells[vrstica, 5] = raziskovalecObj[0].CONTACT[0].EMAIL;
                    else
                        xlWorkSheet.Cells[vrstica, 5] = "";
                    xlWorkSheet.Cells[vrstica, 6] = raziskovalec.FIL_DESCR;
                    xlWorkSheet.Cells[vrstica, 7] = raziskovalec.TYPEDESCR;
                    if (raziskovalecObj[0].RECAPITUALITION != null)
                        xlWorkSheet.Cells[vrstica, 8] = raziskovalecObj[0].RECAPITUALITION[0].A11;
                    else
                        xlWorkSheet.Cells[vrstica, 8] = "";

                    if (raziskovalecObj[0].FRASCATI != null)
                    {
                        string vede = "",podrocje="", podpodrocje="";
                        for (int i = 0; i < raziskovalecObj[0].FRASCATI.Count; i++)
                        {
                            vede += raziskovalecObj[0].FRASCATI[i].SCI_DESCR + "|";
                            podrocje += raziskovalecObj[0].FRASCATI[i].FIL_DESCR + "|";
                            
                            if (raziskovalecObj[0].FRASCATI[i].SUB_DESCR != null)
                                podpodrocje += raziskovalecObj[0].FRASCATI[i].SUB_DESCR + "|";
                            else
                                xlWorkSheet.Cells[vrstica, 10] = "";
                        }

                        xlWorkSheet.Cells[vrstica, 9] = vede;
                        xlWorkSheet.Cells[vrstica, 10] = podrocje;
                        xlWorkSheet.Cells[vrstica, 11] = podpodrocje;
                    }

                    string jeziki = "";
                    if(raziskovalecObj[0].LANGSKILLS != null)
                        for (int i = 0; i < raziskovalecObj[0].LANGSKILLS.Count; i++)
                            jeziki += raziskovalecObj[0].LANGSKILLS[i].LANG_DESCR + "|";
                    xlWorkSheet.Cells[vrstica, 12] = jeziki;

                    string projekti = "";
                    if (raziskovalecObj[0].PROJECTS != null)
                        for (int i = 0; i < raziskovalecObj[0].PROJECTS.Count; i++)
                            projekti += raziskovalecObj[0].PROJECTS[i].TITLE + "|";
                    xlWorkSheet.Cells[vrstica, 13] = projekti;

                    string programi = "";
                    if (raziskovalecObj[0].PROGRAMS != null)
                        for (int i = 0; i < raziskovalecObj[0].PROGRAMS.Count; i++)
                            programi += raziskovalecObj[0].PROGRAMS[i].TITLE + "|";
                    xlWorkSheet.Cells[vrstica, 14] = programi;

                    xlWorkSheet.Cells[vrstica, 15] = raziskovalecObj[0].KEYWS;
                }

                xlWorkSheet.Columns.AutoFit();

                xlWorkBook.SaveAs(saveFileDialog.FileName, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlApp);

                MessageBox.Show("Excel file created");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filename= System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\raziskovalci.xls";
            if (start == true)
            { 
                DialogResult result = openFileDialog1.ShowDialog();
                if (result == DialogResult.OK)
                    filename = openFileDialog1.FileName;
                start = true;
            }
            else
            { 
                Microsoft.Office.Interop.Excel.Application xla = new Microsoft.Office.Interop.Excel.Application();
                //xla.Visible = true;

                Microsoft.Office.Interop.Excel.Workbook wb = xla.Workbooks.Open(filename);

                Microsoft.Office.Interop.Excel.Worksheet ws = wb.Worksheets[1];

                int numberOfRows = xla.Cells.Find("*", System.Reflection.Missing.Value,
                               System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                               Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlPrevious,
                               false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
                int numberOfColumns = xla.Cells.Find("*", System.Reflection.Missing.Value,
                               System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                               Excel.XlSearchOrder.xlByColumns, Excel.XlSearchDirection.xlPrevious,
                               false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Column;

                progressBar1.Value = 0;
                progressBar1.Maximum = numberOfRows;
                double percent = 0;
                listRaziskovalcev.BeginUpdate();
                for (int r = 2; r <=20; r++)
                {
                    Posameznik p = new Posameznik();
                    p.evd_stevilka = ws.Cells[r, 1].Value;
                    if(ws.Cells[r, 2].Value!=null)
                        p.naziv = ws.Cells[r, 2].Value.ToString();
                    p.ime = ws.Cells[r, 3].Value.ToString();
                    p.priimek = ws.Cells[r, 4].Value.ToString();
                    if(ws.Cells[r, 5].Value!=null)
                        p.email = ws.Cells[r, 5].Value.ToString();
                    if(ws.Cells[r, 6].Value!=null)
                        p.raz_pod = ws.Cells[r, 6].Value.ToString();
                    p.status = ws.Cells[r, 7].Value.ToString();
                    if (ws.Cells[r, 8].Value != null)
                        p.tocke = ws.Cells[r, 8].Value.ToString();
                    if (ws.Cells[r, 9].Value!=null)
                        p.vede = ws.Cells[r, 9].Value.ToString();
                    if(ws.Cells[r, 10].Value!=null)
                        p.podrocja = ws.Cells[r, 10].Value.ToString();
                    if(ws.Cells[r, 11].Value!=null)
                        p.podpodrocja = ws.Cells[r, 11].Value.ToString();
                    if(ws.Cells[r, 12].Value!=null)
                        p.jeziki = ws.Cells[r, 12].Value.ToString();
                    if(ws.Cells[r, 13].Value!=null)
                        p.projekti = ws.Cells[r, 13].Value.ToString();
                    if(ws.Cells[r, 14].Value!=null)
                        p.programi = ws.Cells[r, 14].Value.ToString();
                    if(ws.Cells[r, 15].Value != null)
                        p.klj_besede = ws.Cells[r, 15].Value.ToString();
                    posamezniki.Add(p);

                    ListViewItem item = listRaziskovalcev.Items.Add(p.evd_stevilka);
                    item.SubItems.Add(p.naziv);
                    item.SubItems.Add(p.ime);
                    item.SubItems.Add(p.priimek);
                    item.SubItems.Add(p.email);
                    item.SubItems.Add(p.raz_pod);
                    item.SubItems.Add(p.status);
                    item.SubItems.Add(p.tocke);

                    percent = (progressBar1.Value *100)/progressBar1.Maximum;
                    progressPercent.Text = percent.ToString()+"%";
                    progressBar1.Value += 1;
                }
                listRaziskovalcev.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                listRaziskovalcev.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);
                listRaziskovalcev.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize);
                listRaziskovalcev.EndUpdate();
                progressPercent.Text = "100%";
                xla.Quit();
                xla = null;
            }
            

            listRaziskovalcev.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            listRaziskovalcev.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);
            listRaziskovalcev.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize);

            int w = 0;
            for (int i = 0; i < listRaziskovalcev.Columns.Count; i++)
                w += listRaziskovalcev.Columns[i].Width;
            listRaziskovalcev.Width = w+4;

            evidenca_textBox.Enabled = true; naziv_textBox.Enabled = true;
            ime_textBox.Enabled = true; priimek_textBox.Enabled = true;
            raziskovalnoPodrocje_textBox.Enabled = true; status_textBox.Enabled = true;
        }

        private void listRaziskovalcev_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
        {
            e.Cancel = true;
            e.NewWidth = listRaziskovalcev.Columns[e.ColumnIndex].Width;
        }

        private void listRaziskovalcev_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            raz_dejavnost_listView.Items.Clear();
            jeziki_listBox.Items.Clear();
            projekti_ListBox.Items.Clear();
            programi_listBox.Items.Clear();

            if (listRaziskovalcev.SelectedItems.Count == 0)
                return;

            int item = listRaziskovalcev.SelectedItems[0].Index;
            Posameznik p = posamezniki[item];

            string[] vede = p.vede.Split('|');
            string[] podrocja = p.podrocja.Split('|');
            string[] podpodrocja = p.podpodrocja.Split('|');

            for (int i = 0; i < vede.Length; i++)
            {
                ListViewItem rd = new ListViewItem(vede[i]);
                if (i < podrocja.Length)
                    rd.SubItems.Add(podrocja[i]);
                if(i<podpodrocja.Length)
                    rd.SubItems.Add(podpodrocja[i]);

                raz_dejavnost_listView.Items.Add(rd);
            }
            raz_dejavnost_listView.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            raz_dejavnost_listView.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize);
            raz_dejavnost_listView.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.HeaderSize);

            string[] jeziki = p.jeziki.Split('|');
            for(int i=0;i<jeziki.Length-1;i++)
                jeziki_listBox.Items.Add("- " + jeziki[i] + "\n");

            string[] projekti = p.projekti.Split('|');
            for (int i = 0; i < projekti.Length; i++)
                projekti_ListBox.Items.Add(projekti[i]);

            string[] programi = p.programi.Split('|');
            for (int i = 0; i < programi.Length; i++)
                programi_listBox.Items.Add(programi[i]);

        }

        private void ime_textBox_TextChanged(object sender, EventArgs e)
        {
            listRaziskovalcev.Items.Clear();

            foreach (EMPLOY raziskovalec in raziskovalci[0].EMPLOY)
            {
                if (raziskovalec.FNAME == ime_textBox.Text)
                {
                    ListViewItem listViewItem = new ListViewItem(raziskovalec.MSTID);
                    listViewItem.SubItems.Add(raziskovalec.ABBREV);
                    listViewItem.SubItems.Add(raziskovalec.FNAME);
                    listViewItem.SubItems.Add(raziskovalec.LNAME);
                    listViewItem.SubItems.Add(raziskovalec.FIL_DESCR);
                    listViewItem.SubItems.Add(raziskovalec.TYPEDESCR);
                    listViewItem.SubItems.Add(raziskovalec.RSRID);

                    listRaziskovalcev.Items.Add(listViewItem);
                }
            }
        }

        private void add(EMPLOY raziskovalec)
        {
            ListViewItem listViewItem = new ListViewItem(raziskovalec.MSTID);
            listViewItem.SubItems.Add(raziskovalec.ABBREV);
            listViewItem.SubItems.Add(raziskovalec.FNAME);
            listViewItem.SubItems.Add(raziskovalec.LNAME);
            listViewItem.SubItems.Add(raziskovalec.FIL_DESCR);
            listViewItem.SubItems.Add(raziskovalec.TYPEDESCR);
            listViewItem.SubItems.Add(raziskovalec.RSRID);

            listRaziskovalcev.Items.Add(listViewItem);
        }

        public void filtiranjeRaziskovalcev(object sender, EventArgs e)
        {
            listRaziskovalcev.Items.Clear();

            int[] test = { 0, 0, 0, 0, 0 , 0};
            int spremembe = 0;
            int sprememba2 = 0;

            if (evidenca_textBox.Text != ""){
                test[0] = 1;
                spremembe++;
            }
            if (naziv_textBox.Text != ""){
                test[1] = 1;
                spremembe++;
            }
            if (ime_textBox.Text != ""){
                test[2] = 1;
                spremembe++;
            }
            if (priimek_textBox.Text != ""){
                test[3] = 1;
                spremembe++;
            }
            if (raziskovalnoPodrocje_textBox.Text != ""){
                test[4] = 1;
                spremembe++;
            }
            if (status_textBox.Text != ""){
                test[5] = 1;
                spremembe++;
            }
            
            foreach (Posameznik raziskovalec in posamezniki)
            {
                for (int i = 0; i < 6; i++)
                {
                    if (i == 0 && test[0] == 1){
                        if (raziskovalec.evd_stevilka.StartsWith(evidenca_textBox.Text))
                            sprememba2++;
                    }
                    if (i == 1 && test[1] == 1){
                        if (raziskovalec.naziv == null)
                            continue;
                        if (raziskovalec.naziv.ToUpper().StartsWith(naziv_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 2 && test[2] == 1){
                        if (raziskovalec.ime.ToUpper().StartsWith(ime_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 3 && test[3] == 1){
                        if (raziskovalec.priimek.ToUpper().StartsWith(priimek_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 4 && test[4] == 1){
                        if (raziskovalec.raz_pod == null)
                            continue;
                        if (raziskovalec.raz_pod.ToUpper().StartsWith(raziskovalnoPodrocje_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 5 && test[5] == 1){
                        if (raziskovalec.status.ToUpper().StartsWith(status_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                }
                if (sprememba2 == spremembe)
                {
                    ListViewItem listViewItem = new ListViewItem(raziskovalec.evd_stevilka);
                    listViewItem.SubItems.Add(raziskovalec.naziv);
                    listViewItem.SubItems.Add(raziskovalec.ime);
                    listViewItem.SubItems.Add(raziskovalec.priimek);
                    listViewItem.SubItems.Add(raziskovalec.email);
                    listViewItem.SubItems.Add(raziskovalec.raz_pod);
                    listViewItem.SubItems.Add(raziskovalec.status);
                    listViewItem.SubItems.Add(raziskovalec.tocke);

                    listRaziskovalcev.Items.Add(listViewItem);
                }
                sprememba2 = 0;
                
            }
        }

        private void raziskovalciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fakultete_panel.Hide();
            raziskovalci_panel.Show();
        }

        private void fakulteteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            raziskovalci_panel.Hide();
            fakultete_panel.Show();

            string filename = System.IO.Path.GetDirectoryName(Application.ExecutablePath) + @"\fakultete.xls";

            Microsoft.Office.Interop.Excel.Application xla = new Microsoft.Office.Interop.Excel.Application();

            Microsoft.Office.Interop.Excel.Workbook wb = xla.Workbooks.Open(filename);

            Microsoft.Office.Interop.Excel.Worksheet ws = wb.Worksheets[1];

            int numberOfRows = xla.Cells.Find("*", System.Reflection.Missing.Value,
                           System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                           Excel.XlSearchOrder.xlByRows, Excel.XlSearchDirection.xlPrevious,
                           false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Row;
            int numberOfColumns = xla.Cells.Find("*", System.Reflection.Missing.Value,
                           System.Reflection.Missing.Value, System.Reflection.Missing.Value,
                           Excel.XlSearchOrder.xlByColumns, Excel.XlSearchDirection.xlPrevious,
                           false, System.Reflection.Missing.Value, System.Reflection.Missing.Value).Column;

            progressBar2.Value = 0;
            progressBar2.Maximum = numberOfRows;
            double percent = 0;
            for (int r = 2; r <= numberOfRows; r++)
            {
                Faculty f = new Faculty();
                f.ime = ws.Cells[r, 1].Value;
                f.mesto = ws.Cells[r, 2].Value;
                f.odg_oseba = ws.Cells[r, 3].Value;
                f.naslov = ws.Cells[r, 4].Value;
                f.telefon = ws.Cells[r, 5].Value;
                f.faks = ws.Cells[r, 6].Value;
                f.email = ws.Cells[r, 7].Value;
                f.url = ws.Cells[r, 8].Value;
                f.arrs_veda = ws.Cells[r, 9].Value;
                f.arrs_podrocje = ws.Cells[r, 10].Value;
                f.arrs_podpodrocje = ws.Cells[r, 11].Value;
                f.cerif_veda = ws.Cells[r, 12].Value;
                f.ceirf_podrocje = ws.Cells[r, 13].Value;
                f.corids = ws.Cells[r, 14].Value;
                f.zaposleni = ws.Cells[r, 15].Value;
                f.projekti = ws.Cells[r, 16].Value;
                f.programi = ws.Cells[r, 17].Value;
                f.med_projekti = ws.Cells[r, 18].Value;
                f.skupine = ws.Cells[r, 19].Value;

                faculties.Add(f);
                fakultete_listBox.Items.Add(f.ime);

                percent = (progressBar2.Value * 100) / progressBar2.Maximum;
                progressPercent2.Text = percent.ToString() + "%";
                progressBar2.Value += 1;
            }
            progressBar2.Value = numberOfRows;
            progressPercent2.Text = "100%";
            xla.Quit();
            xla = null;
        }

        private void navodilaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void evidenčnaŠtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (evidenčnaŠtToolStripMenuItem.Checked == false)
            {
                listRaziskovalcev.Columns[0].Width = 0;
            }
            else
            {
                listRaziskovalcev.Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void nazivToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (nazivToolStripMenuItem.Checked == false)
            {
                listRaziskovalcev.Columns[1].Width = 0;
            }
            else
            {
                listRaziskovalcev.Columns[1].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void imeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (imeToolStripMenuItem.Checked == false)
            {
                listRaziskovalcev.Columns[2].Width = 0;
            }
            else
            {
                listRaziskovalcev.Columns[2].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void priimekToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (priimekToolStripMenuItem.Checked == false)
            {
                listRaziskovalcev.Columns[3].Width = 0;
            }
            else
            {
                listRaziskovalcev.Columns[3].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void raziskPodročjeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (raziskPodročjeToolStripMenuItem.Checked == false)
            {
                listRaziskovalcev.Columns[4].Width = 0;
            }
            else
            {
                listRaziskovalcev.Columns[4].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void statusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (statusToolStripMenuItem.Checked == false)
            {
                listRaziskovalcev.Columns[5].Width = 0;
            }
            else
            {
                listRaziskovalcev.Columns[5].AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
        }

        private void listRaziskovalcev_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column != sortColumn) //ali smo kliknili na isti stolpec
            {
                sortColumn = e.Column;
                listRaziskovalcev.Sorting = SortOrder.Ascending; //privzeto razvrščanje
            }
            else
            {
                if (listRaziskovalcev.Sorting == SortOrder.Ascending)
                {
                    listRaziskovalcev.Sorting = SortOrder.Descending;
                }
                else
                {
                    listRaziskovalcev.Sorting = SortOrder.Ascending;
                }
            }
            listRaziskovalcev.Sort();
            this.listRaziskovalcev.ListViewItemSorter = new ListViewItemComparer(e.Column, listRaziskovalcev.Sorting);
        }

        class ListViewItemComparer : IComparer //razred za sortiranje
        {
            private int col;
            private SortOrder order;
            public ListViewItemComparer()
            {
                col = 0;
                order = SortOrder.Ascending;
            }
            public ListViewItemComparer(int column, SortOrder order)
            {
                col = column;
                this.order = order;
            }
            public int Compare(object x, object y) //primerjava
            {
                int returnVal = -1;
                returnVal = String.Compare(((ListViewItem)x).SubItems[col].Text, ((ListViewItem)y).SubItems[col].Text);

                if (order == SortOrder.Descending)
                {
                    returnVal *= -1;
                }

                return returnVal;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button2_Click(null, null);
        }

        private void raz_dejavnost_listView_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
        {
            e.Cancel = true;
            e.NewWidth = listRaziskovalcev.Columns[e.ColumnIndex].Width;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Excel files(*.xls)| *.xls|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

                if (xlApp == null)
                {
                    MessageBox.Show("Excel is not properly installed!!");
                    return;
                }

                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                Excel.Range formatRange;
                formatRange = xlWorkSheet.get_Range("A:A");
                formatRange.NumberFormat = "@";

                xlWorkSheet.Cells[1, 1] = "IME";
                xlWorkSheet.Cells[1, 2] = "MESTO";
                xlWorkSheet.Cells[1, 3] = "ODGOVORNA OSEBA";
                xlWorkSheet.Cells[1, 4] = "NASLOV";
                xlWorkSheet.Cells[1, 5] = "TELEFON";
                xlWorkSheet.Cells[1, 6] = "FAKS";
                xlWorkSheet.Cells[1, 7] = "EMAIL";
                xlWorkSheet.Cells[1, 8] = "URL";
                xlWorkSheet.Cells[1, 9] = "ARRS VEDA";
                xlWorkSheet.Cells[1, 10] = "ARRS PODROČJE";
                xlWorkSheet.Cells[1, 11] = "ARRS PODPODROČJE";
                xlWorkSheet.Cells[1, 12] = "CERIF VEDA";
                xlWorkSheet.Cells[1, 13] = "CERIF PODROČJE";
                xlWorkSheet.Cells[1, 14] = "CORDIS OPIS";
                xlWorkSheet.Cells[1, 15] = "ZAPOSLENI";
                xlWorkSheet.Cells[1, 16] = "PROJEKTI";
                xlWorkSheet.Cells[1, 17] = "PROGRAMI";
                xlWorkSheet.Cells[1, 18] = "MEDNARODNI PROJEKTI";
                xlWorkSheet.Cells[1, 19] = "SKUPINE";

                string json = "";
                using (WebClient wc = new WebClient())
                {
                    wc.Encoding = System.Text.Encoding.UTF8;
                    json = wc.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=mstid,name,city,orgid,rsrid,rsr_mstid,dir_lname,dir_fname,dirfun,dirttlpre,dirttlpost,regnum&country=SI_JSON&entity=ORG&methodCall=nameadvanced=name=%20and%20sci=%20and%20fil=%20and%20sub=%20and%20statfrm=21%20and%20lang=slv");
                }

                fakultete = JsonConvert.DeserializeObject<List<Fakultete>>(json);

                int vrstica = 1;
                string arrs_veda = "", arrs_podrocje = "", arrs_podpodrocje = "";
                string cerif_veda = "", cerif_podrocje = "";
                string cordis = "";
                string raz = "", projekti="", programi="", med_projekti="", skupine="";
                foreach (Fakultete f in fakultete)
                {
                    string idFakultete = f.ORGID;

                    using (WebClient wc = new WebClient())
                    {
                        wc.Encoding = System.Text.Encoding.UTF8;
                        json = wc.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=&country=SI_JSON&entity=org&methodCall=id=" + idFakultete + "%20and%20lang=slv");

                    }

                    List<Fakulteta> fakulteta = JsonConvert.DeserializeObject<List<Fakulteta>>(json);

                    vrstica++;
                    xlWorkSheet.Cells[vrstica, 1] = fakulteta[0].NAME;
                    xlWorkSheet.Cells[vrstica, 2] = fakulteta[0].CITY;
                    xlWorkSheet.Cells[vrstica, 3] = fakulteta[0].DIRTTLPRE + " " + fakulteta[0].DIR_FNAME + " " + fakulteta[0].DIR_LNAME + " - " + fakulteta[0].DIRFUN;
                    xlWorkSheet.Cells[vrstica, 4] = fakulteta[0].CONTACT[0].ADDR1 + ", " + fakulteta[0].CONTACT[0].POSTALCODE + fakulteta[0].CONTACT[0].CITY + ", " + fakulteta[0].CONTACT[0].COUNTRY;
                    xlWorkSheet.Cells[vrstica, 5] = fakulteta[0].CONTACT[0].TEL1;
                    xlWorkSheet.Cells[vrstica, 6] = fakulteta[0].CONTACT[0].FAX;
                    xlWorkSheet.Cells[vrstica, 7] = fakulteta[0].CONTACT[0].EMAIL;
                    xlWorkSheet.Cells[vrstica, 8] = fakulteta[0].CONTACT[0].URL;

                    
                    for(int i=0;i<fakulteta[0].FRASCATI.Count;i++)
                    {
                        if (fakulteta[0].FRASCATI[i].SCI_DESCR != null)
                            arrs_veda += fakulteta[0].FRASCATI[i].SCI_DESCR + "|";
                        if (fakulteta[0].FRASCATI[i].FIL_DESCR != null)
                            arrs_podrocje += fakulteta[0].FRASCATI[i].FIL_DESCR + "|";
                        if(fakulteta[0].FRASCATI[i].SUBFIELD!=null)
                            arrs_podpodrocje += fakulteta[0].FRASCATI[i].SUB_DESCR + "|";
                    }
                    xlWorkSheet.Cells[vrstica, 9] = arrs_veda;
                    xlWorkSheet.Cells[vrstica, 10] = arrs_podrocje;
                    xlWorkSheet.Cells[vrstica, 11] = arrs_podpodrocje;
                    arrs_veda = "";arrs_podrocje = "";arrs_podpodrocje = "";

                    for (int i=0;i<fakulteta[0].CERIF.Count;i++)
                    {
                        cerif_veda += fakulteta[0].CERIF[i].DESCR1 + "|";
                        cerif_podrocje += fakulteta[0].CERIF[i].DESCR2 + "|";
                    }
                    xlWorkSheet.Cells[vrstica, 12] = cerif_veda;
                    xlWorkSheet.Cells[vrstica, 13] = cerif_podrocje;
                    cerif_veda = "";cerif_podrocje = "";

                    for (int i = 0; i < fakulteta[0].CORDIS.Count; i++)
                        cordis += fakulteta[0].CORDIS[i].DESCR1 + "|";
                    xlWorkSheet.Cells[vrstica, 14] = cordis;
                    cordis = "";

                    for (int i = 0; i < fakulteta[0].EMPLOY.Count; i++)
                        raz += fakulteta[0].EMPLOY[i].LNAME + " " + fakulteta[0].EMPLOY[i].FNAME + "|";
                    xlWorkSheet.Cells[vrstica, 15] = raz;
                    raz = "";

                    if (fakulteta[0].PROJECTS != null)
                    {
                        for (int i = 0; i < fakulteta[0].PROJECTS.Count; i++)
                            projekti += fakulteta[0].PROJECTS[i].TITLE + "|";
                        xlWorkSheet.Cells[vrstica, 16] = projekti;
                        projekti = "";
                    }

                    if (fakulteta[0].PROGRAMS != null)
                    {
                        for (int i = 0; i < fakulteta[0].PROGRAMS.Count; i++)
                            programi += fakulteta[0].PROGRAMS[i].TITLE + "|";
                        xlWorkSheet.Cells[vrstica, 17] = programi;
                        programi = "";
                    }

                    if (fakulteta[0].INTERNATIONAL != null)
                    {
                        for (int i = 0; i < fakulteta[0].INTERNATIONAL.Count; i++)
                            med_projekti += fakulteta[0].INTERNATIONAL[i].TITLE + "|";
                        xlWorkSheet.Cells[vrstica, 18] = med_projekti;
                        med_projekti = "";
                    }

                    for (int i = 0; i < fakulteta[0].GROUPS.Count; i++)
                        skupine += fakulteta[0].GROUPS[i].GRP_NAME + "|";
                    xlWorkSheet.Cells[vrstica, 19] = skupine;
                    skupine = "";
                }

                xlWorkSheet.Columns.AutoFit();

                xlWorkBook.SaveAs(saveFileDialog.FileName, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();

                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(xlApp);

                MessageBox.Show("Excel file created");
            }
        }

        private void fakultete_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            arrs.Items.Clear();
            cerif.Items.Clear();
            cordis.Items.Clear();
            projekti.Items.Clear();
            programi.Items.Clear();
            skupine.Items.Clear();
            zaposleni.Items.Clear();

            if (fakultete_listBox.SelectedItems.Count == 0)
                return;

            int izbrano = fakultete_listBox.SelectedIndex;

            imeFakulteta.Text = faculties[izbrano].ime;
            mestoFakulteta.Text = "Mesto: " + faculties[izbrano].mesto;
            odgovornaosebaFakulteta.Text = "Odgovorna oseba: " + faculties[izbrano].odg_oseba;
            naslovFakulteta.Text = "Naslov: " + faculties[izbrano].naslov;
            telefonFakulteta.Text = "Telefon: " + faculties[izbrano].telefon;
            faksFakulteta.Text = "Faks: " + faculties[izbrano].faks;
            emailFakulteta.Text = "Email: " + faculties[izbrano].email;
            spletFakulteta.Text = "Spletni naslov: " + faculties[izbrano].url;


            string[] av = new string[50];
            string[] ap = new string[50];
            string[] app = new string[50];
            if(faculties[izbrano].arrs_veda!=null)
                av = faculties[izbrano].arrs_veda.Split('|');
            if (faculties[izbrano].arrs_podrocje != null)
                ap = faculties[izbrano].arrs_podrocje.Split('|');
            if (faculties[izbrano].arrs_podpodrocje != null)
                app = faculties[izbrano].arrs_podpodrocje.Split('|');
            if (av[0] != null)
            {
                for (int i = 0; i < av.Length; i++)
                {
                    ListViewItem a = new ListViewItem(av[i]);

                    if(i < ap.Length)
                        if(ap[i]!=null)
                            a.SubItems.Add(ap[i]);
                    if(i < app.Length - 1)
                        if (app[i] != null)
                            a.SubItems.Add(app[i]);

                    arrs.Items.Add(a);
                }
                arrs.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                arrs.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize);
                arrs.AutoResizeColumn(2, ColumnHeaderAutoResizeStyle.HeaderSize);
            }
            

            string[] cv = faculties[izbrano].cerif_veda.Split('|');
            string[] cp = faculties[izbrano].ceirf_podrocje.Split('|');
            for(int i=0;i<cv.Length;i++)
            {
                ListViewItem c = new ListViewItem(cv[i]);
                c.SubItems.Add(cv[i]);
                cerif.Items.Add(c);
            }
            cerif.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

            if (faculties[izbrano].corids != null)
            {
                string[] cor = faculties[izbrano].corids.Split('|');
                for (int i = 0; i < cor.Length; i++)
                    cordis.Items.Add(cor[i]);
            }

            if (faculties[izbrano].projekti != null)
            {
                string[] projects = faculties[izbrano].projekti.Split('|');
                for (int i = 0; i < projects.Length; i++)
                    projekti.Items.Add(projects[i]);
            }

            if (faculties[izbrano].programi != null)
            {
                string[] programs = faculties[izbrano].programi.Split('|');
                for (int i = 0; i < programs.Length; i++)
                    programi.Items.Add(programs[i]);
            }

            if (faculties[izbrano].skupine != null)
            {
                string[] groups = faculties[izbrano].skupine.Split('|');
                for (int i = 0; i < groups.Length; i++)
                    skupine.Items.Add(groups[i]);
            }

            if (faculties[izbrano].zaposleni != null)
            {
                string[] workers = faculties[izbrano].zaposleni.Split('|');
                for (int i = 0; i < workers.Length; i++)
                    zaposleni.Items.Add(workers[i]);
            }
        }

        private void buttonKeyword_Click(object sender, EventArgs e)
        {
            string keyword = textBoxKeyword.Text;
            bool ujemanje = false;
            listRaziskovalcev.Items.Clear();
            foreach (Posameznik oseba in posamezniki)
            {
                if (oseba.ime.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.priimek.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.email.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.raz_pod.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.status.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.jeziki.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.klj_besede.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.podrocja.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.podpodrocja.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.programi.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.projekti.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }
                else if (oseba.vede.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    ujemanje = true;
                }

                if (ujemanje == true)
                {
                    ListViewItem listViewItem = new ListViewItem(oseba.evd_stevilka);
                    listViewItem.SubItems.Add(oseba.naziv);
                    listViewItem.SubItems.Add(oseba.ime);
                    listViewItem.SubItems.Add(oseba.priimek);
                    listViewItem.SubItems.Add(oseba.email);
                    listViewItem.SubItems.Add(oseba.raz_pod);
                    listViewItem.SubItems.Add(oseba.status);
                    listViewItem.SubItems.Add(oseba.tocke);

                    listRaziskovalcev.Items.Add(listViewItem);
                }
                ujemanje = false;
            }
 
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }

}
