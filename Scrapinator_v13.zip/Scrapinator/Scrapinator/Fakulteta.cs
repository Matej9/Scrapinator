﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scrapinator
{
    class Fakulteta
    {
        public string MSTID { get; set; }
        public string NAME { get; set; }
        public string CITY { get; set; }
        public string ORGID { get; set; }
        public string RSRID { get; set; }
        public string RSR_MSTID { get; set; }
        public string DIR_LNAME { get; set; }
        public string DIR_FNAME { get; set; }
        public string DIRFUN { get; set; }
        public string DIRTTLPRE { get; set; }
        public string statadm { get; set; }
        public string regnum { get; set; }
        public string HEADCNT { get; set; }
        public string RESCNT { get; set; }
        public string STATFRM { get; set; }
        public string ANNUAL_TURN { get; set; }
        public string SIGLA { get; set; }
        public string RESTYPE { get; set; }
        public string STAT { get; set; }
        public string STATFRM_DESCR { get; set; }
        public List<CONTACT_FAKULTETA> CONTACT { get; set; }
        public List<FRASCATI_FAKULTETA> FRASCATI { get; set; }
        public List<CERIF_FAKULTETA> CERIF { get; set; }
        public List<CORDI_FAKULTETA> CORDIS { get; set; }
        public List<NACE> NACE { get; set; }
        public List<RECAPITUALITION_FAKULTETA> RECAPITUALITION { get; set; }
        public List<CITATION_FAKULTETA> CITATIONS { get; set; }
        public List<EMPLOY_FAKULTETA> EMPLOY { get; set; }
        public List<GROUP_FAKULTETA> GROUPS { get; set; }
        public List<PROJECT_FAKULTETA> PROJECTS { get; set; }
        public List<PROGRAM_FAKULTETA> PROGRAMS { get; set; }
        public List<INTERNATIONAL_FAKULTETA> INTERNATIONAL { get; set; }
        public List<EQUIPMENT> EQUIPMENT { get; set; }
        public List<MENTOR> MENTORS { get; set; }
    }

    public class CONTACT_FAKULTETA
    {
        public string ADDR1 { get; set; }
        public string POSTALCODE { get; set; }
        public string CITY { get; set; }
        public string COUNTRY { get; set; }
        public string TEL1 { get; set; }
        public string FAX { get; set; }
        public string EMAIL { get; set; }
        public string URL { get; set; }
    }

    public class FRASCATI_FAKULTETA
    {
        public string SCIENCE { get; set; }
        public string FIELD { get; set; }
        public string SUBFIELD { get; set; }
        public string WEIGHT { get; set; }
        public string SCI_DESCR { get; set; }
        public string FIL_DESCR { get; set; }
        public string SUB_DESCR { get; set; }
    }

    public class CERIF_FAKULTETA
    {
        public string CODE1 { get; set; }
        public string WEIGHT { get; set; }
        public string CODE2 { get; set; }
        public string DESCR1 { get; set; }
        public string DESCR2 { get; set; }
    }

    public class CORDI_FAKULTETA
    {
        public string CODE1 { get; set; }
        public string WEIGHT { get; set; }
        public string DESCR1 { get; set; }
    }

    public class NACE
    {
        public string CODE1 { get; set; }
        public string PART { get; set; }
        public string WEIGHT { get; set; }
        public string CODE2 { get; set; }
        public string DESCR1 { get; set; }
        public string DESCR2 { get; set; }
    }

    public class RECAPITUALITION_FAKULTETA
    {
        public string A11 { get; set; }
        public string A12 { get; set; }
        public string A1_Score { get; set; }
        public string A3_Score { get; set; }
        public string AI { get; set; }
        public string AII { get; set; }
        public string CI_10 { get; set; }
        public string CI_Max { get; set; }
        public string __invalid_name__hindex { get; set; }
        public string MSTID { get; set; }
        public string SCIENCE { get; set; }
    }

    public class CITATION_FAKULTETA
    {
        public string conections_wos { get; set; }
        public string citations_wos { get; set; }
        public string pure_citations_wos { get; set; }
        public string conections_scopus { get; set; }
        public string citations_scopus { get; set; }
        public string pure_citations_scopus { get; set; }
    }

    public class EMPLOY_FAKULTETA
    {
        public string MSTID { get; set; }
        public string LNAME { get; set; }
        public string FNAME { get; set; }
        public string STAT { get; set; }
        public string RSR_STATADM { get; set; }
        public string TYPE { get; set; }
        public string ALLOW { get; set; }
        public string TYPEDESCR { get; set; }
        public string ABBREV { get; set; }
        public string WEIGHT { get; set; }
        public string RSRID { get; set; }
        public string SCIENCE { get; set; }
        public string FIELD { get; set; }
        public string SUBFIELD { get; set; }
        public string SCI_DESCR { get; set; }
        public string FIL_DESCR { get; set; }
        public string ROLECODE { get; set; }
        public string LVLCODE { get; set; }
        public string STARTYEAR { get; set; }
        public string SUB_DESCR { get; set; }
    }

    public class GROUP_FAKULTETA
    {
        public string GRP_MSTID { get; set; }
        public string GRP_NAME { get; set; }
        public string MSTRANK { get; set; }
        public string LNAME { get; set; }
        public string FNAME { get; set; }
        public string RSR_MSTID { get; set; }
        public string RSRID { get; set; }
        public string GRPID { get; set; }
        public string GRP_STATADM { get; set; }
        public string RSR_STATADM { get; set; }
    }

    public class PROJECT_FAKULTETA
    {
        public string MSTID_PRG { get; set; }
        public string MSTID_SCIENCE { get; set; }
        public string PRJ_STATADM { get; set; }
        public string MSTID_CONTR { get; set; }
        public string TITLE { get; set; }
        public string oldmstid { get; set; }
        public string STARTDATE { get; set; }
        public string ENDDATE { get; set; }
        public string PRJID { get; set; }
        public string FNAME { get; set; }
        public string LNAME { get; set; }
        public string RSR_MSTID { get; set; }
        public string RSR_STATADM { get; set; }
        public string RSRID { get; set; }
        public string FRAME { get; set; }
    }

    public class PROGRAM_FAKULTETA
    {
        public string MSTID_PRG { get; set; }
        public string MSTID_SCIENCE { get; set; }
        public string PRJ_STATADM { get; set; }
        public string MSTID_CONTR { get; set; }
        public string TITLE { get; set; }
        public string oldmstid { get; set; }
        public string STARTDATE { get; set; }
        public string ENDDATE { get; set; }
        public string PRJID { get; set; }
        public string FNAME { get; set; }
        public string LNAME { get; set; }
        public string RSR_MSTID { get; set; }
        public string RSR_STATADM { get; set; }
        public string RSRID { get; set; }
        public string FRAME { get; set; }
    }

    public class INTERNATIONAL_FAKULTETA
    {
        public string MSTID_PRG { get; set; }
        public string MSTID_SCIENCE { get; set; }
        public string PRJ_STATADM { get; set; }
        public string MSTID_CONTR { get; set; }
        public string TITLE { get; set; }
        public string STARTDATE { get; set; }
        public string ENDDATE { get; set; }
        public string PRJID { get; set; }
        public string FRAME { get; set; }
        public string oldmstid { get; set; }
        public string FNAME { get; set; }
        public string LNAME { get; set; }
        public string RSR_MSTID { get; set; }
        public string RSR_STATADM { get; set; }
        public string RSRID { get; set; }
    }

    public class EQUIPMENT
    {
        public string equipid { get; set; }
        public string equip_name { get; set; }
        public string package { get; set; }
        public string price { get; set; }
        public string year { get; set; }
        public string descr { get; set; }
        public string offer { get; set; }
        public string rsr_mstid { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public string rsrid { get; set; }
        public string rsr_statadm { get; set; }
        public string equip_stat { get; set; }
        public string equip_package { get; set; }
    }

    public class MENTOR
    {
        public string MSTID { get; set; }
        public string RSRID { get; set; }
        public string LNAME { get; set; }
        public string FNAME { get; set; }
        public string TYPE { get; set; }
        public string ALLOW { get; set; }
        public string TYPEDESCR { get; set; }
        public string ABBREV { get; set; }
        public string WEIGHT { get; set; }
        public string LVLCODE { get; set; }
        public string SCIENCE { get; set; }
        public string RSR_STATADM { get; set; }
        public string FIELD { get; set; }
        public string SUBFIELD { get; set; }
        public string SCI_DESCR { get; set; }
        public string STAT { get; set; }
        public string FIL_DESCR { get; set; }
        public string SUB_DESCR { get; set; }
        public string statadm { get; set; }
    }
}

