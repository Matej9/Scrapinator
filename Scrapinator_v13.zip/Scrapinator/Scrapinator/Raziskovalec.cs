﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScrapinatorRaziskovalec
{
        public class CONTACT
        {
            public string EMAIL { get; set; }
        }
        public class FRASCATI
        {
            public string SCIENCE { get; set; }
            public string FIELD { get; set; }
            public string SUBFIELD { get; set; }
            public string WEIGHT { get; set; }
            public string SCI_DESCR { get; set; }
            public string FIL_DESCR { get; set; }
            public string SUB_DESCR { get; set; }
        }
        public class REPRESENTBIBL
        {
            public string BIBLIO { get; set; }
        }
        public class RECAPITUALITION
        {
            public string AI { get; set; }
            public string AII { get; set; }
            public string A1_Score { get; set; }
            public string A11 { get; set; }
            public string A12 { get; set; }
            public string A3_Score { get; set; }
            public string A3_Update { get; set; }
            public string A31_Score { get; set; }
            public string A32_Score { get; set; }
            public string A33_Score { get; set; }
            public string A34_Score { get; set; }
            public string A35_Score { get; set; }
            public string CI_Max { get; set; }
            public string CI_10 { get; set; }
            public string Cnt_AI { get; set; }
            public string Cnt_AII { get; set; }
            public string Cnt_A12 { get; set; }
            public string Cnt_S { get; set; }
            public string Cnt_Z { get; set; }
            public string Cnt_1A1 { get; set; }
            public string Cnt_1A2 { get; set; }
            public string Cnt_1A3 { get; set; }
            public string Cnt_1A4 { get; set; }
            public string Cnt_1B { get; set; }
            public string Cnt_1C { get; set; }
            public string Cnt_1D { get; set; }
            public string Cnt_2A { get; set; }
            public string Cnt_2B { get; set; }
            public string Cnt_2C { get; set; }
            public string Cnt_2E { get; set; }
            public string Cnt_2F { get; set; }
            public string Cnt_2G { get; set; }
            public string Cnt_2H { get; set; }
            public string Cnt_2I { get; set; }
            public string Cnt_2J { get; set; }
            public string Cnt_3A { get; set; }
            public string Cnt_3B { get; set; }
            public string Cnt_3C { get; set; }
            public string Cnt_3D { get; set; }
            public string Cnt_3E { get; set; }
            public string Cnt_3F { get; set; }
            public string Cnt_4C { get; set; }
            public string Cnt_4D { get; set; }
            public string h_index { get; set; }// h-index ne dela
            public string Z { get; set; }
            public string IABC { get; set; }//1ABC ne dela
            public string TA3AB { get; set; }//2A3AB ne dela
            public string SCIENCE { get; set; }
        }
        public class CITATIONS
        {
            public string WOS_CONNECTIONS { get; set; }
            public string WOS_CITATIONS { get; set; }
            public string WOS_PURE_CITATIONS { get; set; }
            public string SCOPUS_CONNECTIONS { get; set; }
            public string SCOPUS_CITATIONS { get; set; }
            public string SCOPUS_PURE_CITATIONS { get; set; }
            public string OPENCIT_CONNECTIONS { get; set; }
            public string OPENCIT_CITATIONS { get; set; }
            public string WOS_DIV { get; set; }
            public string SCOPUS_DIV { get; set; }
        }
        public class THESES
        {
            public string CID { get; set; }
            public string TYPOLOGY { get; set; }
            public string DOCTYPE { get; set; }
            public string TITLE { get; set; }
            public string FROMYEAR { get; set; }
            public string PAGES { get; set; }
            public string DATECRE { get; set; }
        }

        public class EDUCATION
        {
            public string EDULVL { get; set; }
            public string DEGREE { get; set; }
            public string INSTNAME1 { get; set; }
            public string INSTNAME2 { get; set; }
            public string COUNTRY { get; set; }
            public string FIELD { get; set; }
            public string YEAR { get; set; }
            public string LVLCODE { get; set; }
            public string COUNTRYCODE { get; set; }
        }
        public class LANGSKILLS
        {
            public string LANG_DESCR { get; set; }
            public string LANGCODE { get; set; }
            public string SKILLRD { get; set; }
            public string SKILLWR { get; set; }
            public string SKILLSPK { get; set; }
            public string SKILLRD_CODE { get; set; }
            public string SKILLWR_CODE { get; set; }
            public string SKILLSPK_CODE { get; set; }
        }
        public class EMPLOY
        {
            public string RSRTTLDATE { get; set; }
            public string startdate { get; set; }
            public string POSITION { get; set; }
            public string RSRTTL { get; set; }
            public string RSRTTLCODE { get; set; }
            public string RSRTTLBY { get; set; }
            public string ORGID { get; set; }
            public string ORG_NAME { get; set; }
            public string org_mstid { get; set; }
            public string GRP_NAME { get; set; }
            public string grp_mstid { get; set; }
            public string GRPID { get; set; }
            public string RSRLOAD { get; set; }
            public string RESEARCHLOAD { get; set; }
            public string EMPLTYP { get; set; }
        }
        public class PROJECTS
        {
            public string MSTID_PRG { get; set; }
            public string MSTID_SCIENCE { get; set; }
            public string MSTID_CONTR { get; set; }
            public string TITLE { get; set; }
            public string STARTDATE { get; set; }
            public string ENDDATE { get; set; }
            public string oldmstid { get; set; }
            public string PRJID { get; set; }
            public string PRJ_STATADM { get; set; }
            public string FNAME { get; set; }
            public string LNAME { get; set; }
            public string EMPLTYP { get; set; }
            public string RSR_MSTID { get; set; }
            public string RSR_STATADM { get; set; }
            public string RSRID { get; set; }
            public string FRAME { get; set; }
        }

        public class PROGRAM
        {
            public string MSTID_PRG { get; set; }
            public string MSTID_SCIENCE { get; set; }
            public string MSTID_CONTR { get; set; }
            public string TITLE { get; set; }
            public string STARTDATE { get; set; }
            public string ENDDATE { get; set; }
            public string oldmstid { get; set; }
            public string PRJID { get; set; }
            public string PRJ_STATADM { get; set; }
            public string FNAME { get; set; }
            public string LNAME { get; set; }
            public string RSR_MSTID { get; set; }
            public string RSR_STATADM { get; set; }
            public string RSRID { get; set; }
            public string FRAME { get; set; }
        }

        public class YNGRESEARCHERS
        {
            public string MSTID { get; set; }
            public string RSRID { get; set; }
            public string LNAME { get; set; }
            public string FNAME { get; set; }
            public string ABBREV { get; set; }
            public string WEIGHT { get; set; }
            public string LVLCODE { get; set; }
            public string SCIENCE { get; set; }
            public string FIELD { get; set; }
            public string SUBFIELD { get; set; }
            public string SCI_DESCR { get; set; }
            public string STAT { get; set; }
            public string FIL_DESCR { get; set; }
            public string SUB_DESCR { get; set; }
            public string statadm { get; set; }
            public string YNG_ROL { get; set; }
            public string ROLECODE { get; set; }
            public string startdate { get; set; }
            public string enddate { get; set; }
            public string TTL_STAT { get; set; }
            public string TTL_PRE { get; set; }
            public string TTL_POST { get; set; }
            public string ORG_NAME { get; set; }
            public string ORGID { get; set; }
        }
        public class Raziskovalec
        {
            public string MSTID { get; set; }
            public string RSRID { get; set; }
            public string LNAME { get; set; }
            public string FNAME { get; set; }
            public string TYPE { get; set; }
            public string ABBREV { get; set; }
            public string SCIENCE { get; set; }
            public string FIELD { get; set; }
            public string SUBFIELD { get; set; }
            public string STAT { get; set; }
            public string statadm { get; set; }
            public string ALLOW { get; set; }
            public string KEYWS { get; set; }
            public string CITSHIP { get; set; }
            public IList<CONTACT> CONTACT { get; set; }
            public IList<FRASCATI> FRASCATI { get; set; }
            public IList<REPRESENTBIBL> REPRESENTBIBL { get; set; }
            public IList<RECAPITUALITION> RECAPITUALITION { get; set; }
            public IList<CITATIONS> CITATIONS { get; set; }
            public IList<THESES> THESES { get; set; }
            public IList<EDUCATION> EDUCATION { get; set; }
            public IList<LANGSKILLS> LANGSKILLS { get; set; }
            public IList<EMPLOY> EMPLOY { get; set; }
            public IList<PROJECTS> PROJECTS { get; set; }
            public List<PROGRAM> PROGRAMS { get; set; }
            public IList<YNGRESEARCHERS> YNGRESEARCHERS { get; set; }
    }
    }
