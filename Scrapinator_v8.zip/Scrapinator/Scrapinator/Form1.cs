﻿using Newtonsoft.Json;
using ScrapinatorRaziskovalec;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;


namespace Scrapinator
{

   




    public partial class Form1 : Form
    {
     


       List<Raziskovalci> raziskovalci;
        List<Fakultete> fakultete;
        private bool dobljeneFakultete = false;

        public Form1()
        {
            InitializeComponent();
            listRaziskovalcev.Columns[6].Dispose();//skrijem RSRID polje
            fakultete_listView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;

            


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            listRaziskovalcev.Items.Clear();
            string json = "";
            using (WebClient wc = new WebClient())
            {
                wc.Encoding = System.Text.Encoding.UTF8;
                json = wc.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=&country=SI_JSON&entity=org&methodCall=id=3179%20and%20lang=slv");

            }

            raziskovalci = JsonConvert.DeserializeObject<List<Raziskovalci>>(json);
           
            foreach(EMPLOY raziskovalec in raziskovalci[0].EMPLOY)
            {
                ListViewItem listViewItem = new ListViewItem(raziskovalec.MSTID);
                listViewItem.SubItems.Add(raziskovalec.ABBREV);
                listViewItem.SubItems.Add(raziskovalec.FNAME);
                listViewItem.SubItems.Add(raziskovalec.LNAME);
                listViewItem.SubItems.Add(raziskovalec.FIL_DESCR);
                listViewItem.SubItems.Add(raziskovalec.TYPEDESCR);
                listViewItem.SubItems.Add(raziskovalec.RSRID);

                listRaziskovalcev.Items.Add(listViewItem);
            }
            
            listRaziskovalcev.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
            listRaziskovalcev.AutoResizeColumn(0, ColumnHeaderAutoResizeStyle.HeaderSize);
            listRaziskovalcev.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize);

            evidenca_textBox.Enabled = true; naziv_textBox.Enabled = true;
            ime_textBox.Enabled = true; priimek_textBox.Enabled = true;
            raziskovalnoPodrocje_textBox.Enabled = true; status_textBox.Enabled = true;
        }

        private void listRaziskovalcev_ColumnWidthChanging(object sender, ColumnWidthChangingEventArgs e)
        {
            e.Cancel = true;
            e.NewWidth = listRaziskovalcev.Columns[e.ColumnIndex].Width;
        }

        private void listRaziskovalcev_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (listRaziskovalcev.SelectedItems.Count == 0)
                return;

            ListViewItem item = listRaziskovalcev.SelectedItems[0];

            string rsrid = item.SubItems[6].Text;

            string json = "";
            using (WebClient wc = new WebClient())
            {
                wc.Encoding = Encoding.UTF8;
                json = wc.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=&country=SI_JSON&entity=rsr&methodCall=id="+rsrid+"%20and%20lang=slv");
            }
            List<Raziskovalec> raziskovalecObj = JsonConvert.DeserializeObject<List<Raziskovalec>>(json);//tukaj je celoten objekt raziskovalca

            if(raziskovalecObj[0].ABBREV != null && raziskovalecObj[0].FNAME != null && raziskovalecObj[0].LNAME != null && raziskovalecObj[0].CONTACT[0].EMAIL != null && raziskovalecObj[0].RECAPITUALITION != null) {
                MessageBox.Show("Ime in priimek: " + raziskovalecObj[0].ABBREV + raziskovalecObj[0].FNAME + " " + raziskovalecObj[0].LNAME + "\nemail: " + raziskovalecObj[0].CONTACT[0].EMAIL + " \nTočke: " + raziskovalecObj[0].RECAPITUALITION[0].A11);
            }else
            {
                if (raziskovalecObj[0].RECAPITUALITION == null)
                {
                    MessageBox.Show("Ime in priimek: " + raziskovalecObj[0].ABBREV + raziskovalecObj[0].FNAME + " " + raziskovalecObj[0].LNAME + "\nemail: " + raziskovalecObj[0].CONTACT[0].EMAIL + "\nTočke: brez");
                }
            }
            
        }

        private void ime_textBox_TextChanged(object sender, EventArgs e)
        {
            listRaziskovalcev.Items.Clear();

            foreach (EMPLOY raziskovalec in raziskovalci[0].EMPLOY)
            {
                if (raziskovalec.FNAME == ime_textBox.Text)
                {
                    ListViewItem listViewItem = new ListViewItem(raziskovalec.MSTID);
                    listViewItem.SubItems.Add(raziskovalec.ABBREV);
                    listViewItem.SubItems.Add(raziskovalec.FNAME);
                    listViewItem.SubItems.Add(raziskovalec.LNAME);
                    listViewItem.SubItems.Add(raziskovalec.FIL_DESCR);
                    listViewItem.SubItems.Add(raziskovalec.TYPEDESCR);
                    listViewItem.SubItems.Add(raziskovalec.RSRID);

                    listRaziskovalcev.Items.Add(listViewItem);
                }
            }
        }

        private void add(EMPLOY raziskovalec)
        {
            ListViewItem listViewItem = new ListViewItem(raziskovalec.MSTID);
            listViewItem.SubItems.Add(raziskovalec.ABBREV);
            listViewItem.SubItems.Add(raziskovalec.FNAME);
            listViewItem.SubItems.Add(raziskovalec.LNAME);
            listViewItem.SubItems.Add(raziskovalec.FIL_DESCR);
            listViewItem.SubItems.Add(raziskovalec.TYPEDESCR);
            listViewItem.SubItems.Add(raziskovalec.RSRID);

            listRaziskovalcev.Items.Add(listViewItem);
        }

        public void filtiranjeRaziskovalcev(object sender, EventArgs e)
        {
            listRaziskovalcev.Items.Clear();

            int[] test = { 0, 0, 0, 0, 0 , 0};
            int spremembe = 0;
            int sprememba2 = 0;

            if (evidenca_textBox.Text != ""){
                test[0] = 1;
                spremembe++;
            }
            if (naziv_textBox.Text != ""){
                test[1] = 1;
                spremembe++;
            }
            if (ime_textBox.Text != ""){
                test[2] = 1;
                spremembe++;
            }
            if (priimek_textBox.Text != ""){
                test[3] = 1;
                spremembe++;
            }
            if (raziskovalnoPodrocje_textBox.Text != ""){
                test[4] = 1;
                spremembe++;
            }
            if (status_textBox.Text != ""){
                test[5] = 1;
                spremembe++;
            }
            
            foreach (EMPLOY raziskovalec in raziskovalci[0].EMPLOY)
            {
                for (int i = 0; i < 6; i++)
                {
                    if (i == 0 && test[0] == 1){
                        if (raziskovalec.MSTID.StartsWith(evidenca_textBox.Text))
                            sprememba2++;
                    }
                    if (i == 1 && test[1] == 1){
                        if (raziskovalec.ABBREV == null)
                            continue;
                        if (raziskovalec.ABBREV.ToUpper().StartsWith(naziv_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 2 && test[2] == 1){
                        if (raziskovalec.FNAME.ToUpper().StartsWith(ime_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 3 && test[3] == 1){
                        if (raziskovalec.LNAME.ToUpper().StartsWith(priimek_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 4 && test[4] == 1){
                        if (raziskovalec.FIL_DESCR == null)
                            continue;
                        if (raziskovalec.FIL_DESCR.ToUpper().StartsWith(raziskovalnoPodrocje_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                    if (i == 5 && test[5] == 1){
                        if (raziskovalec.TYPEDESCR.ToUpper().StartsWith(status_textBox.Text.ToUpper()))
                            sprememba2++;
                    }
                }
                if (sprememba2 == spremembe)
                {
                    ListViewItem listViewItem = new ListViewItem(raziskovalec.MSTID);
                    listViewItem.SubItems.Add(raziskovalec.ABBREV);
                    listViewItem.SubItems.Add(raziskovalec.FNAME);
                    listViewItem.SubItems.Add(raziskovalec.LNAME);
                    listViewItem.SubItems.Add(raziskovalec.FIL_DESCR);
                    listViewItem.SubItems.Add(raziskovalec.TYPEDESCR);
                    listViewItem.SubItems.Add(raziskovalec.RSRID);

                    listRaziskovalcev.Items.Add(listViewItem);
                }
                sprememba2 = 0;
                
            }
        }

        private void raziskovalciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fakultete_panel.Hide();
            raziskovalci_panel.Show();
        }

        private void fakulteteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            raziskovalci_panel.Hide();
            fakultete_panel.Show();

            if (!dobljeneFakultete)
            {
                string json = "";
                using (WebClient wc = new WebClient())
                {
                    wc.Encoding = System.Text.Encoding.UTF8;
                    json = wc.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=mstid,name,city,orgid,rsrid,rsr_mstid,dir_lname,dir_fname,dirfun,dirttlpre,dirttlpost,regnum&country=SI_JSON&entity=ORG&methodCall=nameadvanced=name=%20and%20sci=%20and%20fil=%20and%20sub=%20and%20statfrm=21%20and%20lang=slv");

                }

                fakultete = JsonConvert.DeserializeObject<List<Fakultete>>(json);

                foreach (Fakultete fakulteta in fakultete)
                {
                    ListViewItem fak = new ListViewItem(fakulteta.NAME);
                    fak.Tag = fakulteta.ORGID;
                    fakultete_listView.Items.Add(fak);
                }
                fakultete_listView.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                fakultete_listView.Width = fakultete_listView.Columns[0].Width+21;
            }
        }

        private void fakultete_listBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void fakultete_listView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (fakultete_listView.SelectedItems.Count > 0)
            {
                string idFakultete = (string)fakultete_listView.SelectedItems[fakultete_listView.SelectedItems.Count - 1].Tag;
                MessageBox.Show(idFakultete.ToString());

                string json = "";
                using (WebClient wc = new WebClient())
                {
                    wc.Encoding = System.Text.Encoding.UTF8;
                    json = wc.DownloadString("http://www.sicris.si/Common/rest.aspx?sessionID=1234CRIS12002B01B01A03IZUMBFICDOSKJHS588Nn44131&fields=&country=SI_JSON&entity=org&methodCall=id=" + idFakultete + "%20and%20lang=slv");

                }

                List<Fakulteta> fakulteta = JsonConvert.DeserializeObject<List<Fakulteta>>(json);

                imeFakulteta.Text = fakulteta[0].NAME;
                mestoFakulteta.Text = "Mesto: " + fakulteta[0].CITY;
                odgovornaosebaFakulteta.Text = "Odgovorna oseba: " + fakulteta[0].DIRTTLPRE + " " + fakulteta[0].DIR_FNAME + " " + fakulteta[0].DIR_LNAME + " - " + fakulteta[0].DIRFUN;
                statusFakulteta.Text = "Status: " + fakulteta[0].STATFRM_DESCR;
                naslovFakulteta.Text = "Naslov: " + fakulteta[0].CONTACT[0].ADDR1 + ", " + fakulteta[0].CONTACT[0].POSTALCODE + fakulteta[0].CONTACT[0].CITY + ", " + fakulteta[0].CONTACT[0].COUNTRY;
                telefonFakulteta.Text = "Telefon: " + fakulteta[0].CONTACT[0].TEL1;
                faksFakulteta.Text = "Faks: " + fakulteta[0].CONTACT[0].FAX;
                emailFakulteta.Text = "Email: " + fakulteta[0].CONTACT[0].EMAIL;
                spletFakulteta.Text = "Spletni naslov: " + fakulteta[0].CONTACT[0].URL;
            }
        }

        private void navodilaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void roundButton1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Excel files(*.xls)| *.xls|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();

            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }

            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {


                Excel.Range formatRange;
                formatRange = xlWorkSheet.get_Range("A:A");
                formatRange.NumberFormat = "@";


                xlWorkSheet.Cells[1, 1] = "EVIDENČNA ŠT.";
                xlWorkSheet.Cells[1, 2] = "NAZIV";
                xlWorkSheet.Cells[1, 3] = "IME";
                xlWorkSheet.Cells[1, 4] = "PRIIMEK";
                xlWorkSheet.Cells[1, 5] = "RAZISK. PODROČJE";
                xlWorkSheet.Cells[1, 6] = "STATUS";

                int vrstica = 1;

                foreach (EMPLOY raziskovalec in raziskovalci[0].EMPLOY)
                {
                    vrstica++;
                    xlWorkSheet.Cells[vrstica, 1] = raziskovalec.MSTID;
                    xlWorkSheet.Cells[vrstica, 2] = raziskovalec.ABBREV;
                    xlWorkSheet.Cells[vrstica, 3] = raziskovalec.FNAME;
                    xlWorkSheet.Cells[vrstica, 4] = raziskovalec.LNAME;
                    xlWorkSheet.Cells[vrstica, 5] = raziskovalec.FIL_DESCR;
                    xlWorkSheet.Cells[vrstica, 6] = raziskovalec.TYPEDESCR;
                }

                xlWorkSheet.Columns.AutoFit();

            }
            xlWorkBook.SaveAs(saveFileDialog.FileName, Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();

            Marshal.ReleaseComObject(xlWorkSheet);
            Marshal.ReleaseComObject(xlWorkBook);
            Marshal.ReleaseComObject(xlApp);

            MessageBox.Show("Excel file created");
        }

        
    }
}
