﻿namespace Scrapinator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.raziskovalciToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fakulteteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listRaziskovalcev = new System.Windows.Forms.ListView();
            this.Evidencna_st = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.naziv = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.priimek = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.raziskovalno_področje = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.status = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.rsrid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.naziv_textBox = new System.Windows.Forms.TextBox();
            this.evidenca_textBox = new System.Windows.Forms.TextBox();
            this.status_textBox = new System.Windows.Forms.TextBox();
            this.raziskovalnoPodrocje_textBox = new System.Windows.Forms.TextBox();
            this.priimek_textBox = new System.Windows.Forms.TextBox();
            this.ime_textBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.raziskovalci_panel = new System.Windows.Forms.Panel();
            this.fakultete_panel = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.spletFakulteta = new System.Windows.Forms.Label();
            this.emailFakulteta = new System.Windows.Forms.Label();
            this.faksFakulteta = new System.Windows.Forms.Label();
            this.telefonFakulteta = new System.Windows.Forms.Label();
            this.naslovFakulteta = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.statusFakulteta = new System.Windows.Forms.Label();
            this.odgovornaosebaFakulteta = new System.Windows.Forms.Label();
            this.mestoFakulteta = new System.Windows.Forms.Label();
            this.imeFakulteta = new System.Windows.Forms.Label();
            this.fakultete_listView = new System.Windows.Forms.ListView();
            this.imeFakultete = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.raziskovalci_panel.SuspendLayout();
            this.fakultete_panel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.raziskovalciToolStripMenuItem,
            this.fakulteteToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1036, 24);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // raziskovalciToolStripMenuItem
            // 
            this.raziskovalciToolStripMenuItem.Name = "raziskovalciToolStripMenuItem";
            this.raziskovalciToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.raziskovalciToolStripMenuItem.Text = "Raziskovalci";
            this.raziskovalciToolStripMenuItem.Click += new System.EventHandler(this.raziskovalciToolStripMenuItem_Click);
            // 
            // fakulteteToolStripMenuItem
            // 
            this.fakulteteToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.fakulteteToolStripMenuItem.Name = "fakulteteToolStripMenuItem";
            this.fakulteteToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.fakulteteToolStripMenuItem.Text = "Fakultete";
            this.fakulteteToolStripMenuItem.Click += new System.EventHandler(this.fakulteteToolStripMenuItem_Click);
            // 
            // listRaziskovalcev
            // 
            this.listRaziskovalcev.BackColor = System.Drawing.SystemColors.Menu;
            this.listRaziskovalcev.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Evidencna_st,
            this.naziv,
            this.ime,
            this.priimek,
            this.raziskovalno_področje,
            this.status,
            this.rsrid});
            this.listRaziskovalcev.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listRaziskovalcev.FullRowSelect = true;
            this.listRaziskovalcev.GridLines = true;
            this.listRaziskovalcev.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listRaziskovalcev.Location = new System.Drawing.Point(0, 0);
            this.listRaziskovalcev.Margin = new System.Windows.Forms.Padding(2);
            this.listRaziskovalcev.Name = "listRaziskovalcev";
            this.listRaziskovalcev.Size = new System.Drawing.Size(843, 530);
            this.listRaziskovalcev.TabIndex = 2;
            this.listRaziskovalcev.UseCompatibleStateImageBehavior = false;
            this.listRaziskovalcev.View = System.Windows.Forms.View.Details;
            this.listRaziskovalcev.ColumnWidthChanging += new System.Windows.Forms.ColumnWidthChangingEventHandler(this.listRaziskovalcev_ColumnWidthChanging);
            this.listRaziskovalcev.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.listRaziskovalcev_ItemSelectionChanged);
            // 
            // Evidencna_st
            // 
            this.Evidencna_st.Text = "Evidenčna št.";
            this.Evidencna_st.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Evidencna_st.Width = 110;
            // 
            // naziv
            // 
            this.naziv.Text = "Naziv";
            this.naziv.Width = 80;
            // 
            // ime
            // 
            this.ime.Text = "Ime";
            this.ime.Width = 170;
            // 
            // priimek
            // 
            this.priimek.Text = "Priimek";
            this.priimek.Width = 170;
            // 
            // raziskovalno_področje
            // 
            this.raziskovalno_področje.Text = "Razisk. področje";
            this.raziskovalno_področje.Width = 186;
            // 
            // status
            // 
            this.status.Text = "Status";
            this.status.Width = 186;
            // 
            // rsrid
            // 
            this.rsrid.Text = "RSRID";
            this.rsrid.Width = 240;
            // 
            // naziv_textBox
            // 
            this.naziv_textBox.Enabled = false;
            this.naziv_textBox.Location = new System.Drawing.Point(849, 158);
            this.naziv_textBox.Margin = new System.Windows.Forms.Padding(2);
            this.naziv_textBox.Name = "naziv_textBox";
            this.naziv_textBox.Size = new System.Drawing.Size(146, 20);
            this.naziv_textBox.TabIndex = 2;
            this.naziv_textBox.TextChanged += new System.EventHandler(this.filtiranjeRaziskovalcev);
            // 
            // evidenca_textBox
            // 
            this.evidenca_textBox.Enabled = false;
            this.evidenca_textBox.Location = new System.Drawing.Point(849, 110);
            this.evidenca_textBox.Margin = new System.Windows.Forms.Padding(2);
            this.evidenca_textBox.Name = "evidenca_textBox";
            this.evidenca_textBox.Size = new System.Drawing.Size(146, 20);
            this.evidenca_textBox.TabIndex = 1;
            this.evidenca_textBox.TextChanged += new System.EventHandler(this.filtiranjeRaziskovalcev);
            // 
            // status_textBox
            // 
            this.status_textBox.Enabled = false;
            this.status_textBox.Location = new System.Drawing.Point(847, 371);
            this.status_textBox.Margin = new System.Windows.Forms.Padding(2);
            this.status_textBox.Name = "status_textBox";
            this.status_textBox.Size = new System.Drawing.Size(146, 20);
            this.status_textBox.TabIndex = 6;
            this.status_textBox.TextChanged += new System.EventHandler(this.filtiranjeRaziskovalcev);
            // 
            // raziskovalnoPodrocje_textBox
            // 
            this.raziskovalnoPodrocje_textBox.Enabled = false;
            this.raziskovalnoPodrocje_textBox.Location = new System.Drawing.Point(847, 318);
            this.raziskovalnoPodrocje_textBox.Margin = new System.Windows.Forms.Padding(2);
            this.raziskovalnoPodrocje_textBox.Name = "raziskovalnoPodrocje_textBox";
            this.raziskovalnoPodrocje_textBox.Size = new System.Drawing.Size(146, 20);
            this.raziskovalnoPodrocje_textBox.TabIndex = 5;
            this.raziskovalnoPodrocje_textBox.TextChanged += new System.EventHandler(this.filtiranjeRaziskovalcev);
            // 
            // priimek_textBox
            // 
            this.priimek_textBox.Enabled = false;
            this.priimek_textBox.Location = new System.Drawing.Point(847, 264);
            this.priimek_textBox.Margin = new System.Windows.Forms.Padding(2);
            this.priimek_textBox.Name = "priimek_textBox";
            this.priimek_textBox.Size = new System.Drawing.Size(146, 20);
            this.priimek_textBox.TabIndex = 4;
            this.priimek_textBox.TextChanged += new System.EventHandler(this.filtiranjeRaziskovalcev);
            // 
            // ime_textBox
            // 
            this.ime_textBox.Enabled = false;
            this.ime_textBox.Location = new System.Drawing.Point(847, 209);
            this.ime_textBox.Margin = new System.Windows.Forms.Padding(2);
            this.ime_textBox.Name = "ime_textBox";
            this.ime_textBox.Size = new System.Drawing.Size(146, 20);
            this.ime_textBox.TabIndex = 3;
            this.ime_textBox.TextChanged += new System.EventHandler(this.filtiranjeRaziskovalcev);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(847, 141);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Naziv:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(847, 93);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Evidenčna številka:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(847, 355);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Status:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(844, 302);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Raziskovalno področje:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(844, 245);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Priimek:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(847, 193);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ime:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(844, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "--------------FILTRIRANJE--------------";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(847, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(173, 41);
            this.button1.TabIndex = 0;
            this.button1.Text = "PRIKAŽI RAZISKOVALCE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // raziskovalci_panel
            // 
            this.raziskovalci_panel.Controls.Add(this.button2);
            this.raziskovalci_panel.Controls.Add(this.button1);
            this.raziskovalci_panel.Controls.Add(this.label1);
            this.raziskovalci_panel.Controls.Add(this.label2);
            this.raziskovalci_panel.Controls.Add(this.label3);
            this.raziskovalci_panel.Controls.Add(this.label4);
            this.raziskovalci_panel.Controls.Add(this.label5);
            this.raziskovalci_panel.Controls.Add(this.label6);
            this.raziskovalci_panel.Controls.Add(this.ime_textBox);
            this.raziskovalci_panel.Controls.Add(this.priimek_textBox);
            this.raziskovalci_panel.Controls.Add(this.raziskovalnoPodrocje_textBox);
            this.raziskovalci_panel.Controls.Add(this.status_textBox);
            this.raziskovalci_panel.Controls.Add(this.evidenca_textBox);
            this.raziskovalci_panel.Controls.Add(this.label7);
            this.raziskovalci_panel.Controls.Add(this.naziv_textBox);
            this.raziskovalci_panel.Controls.Add(this.listRaziskovalcev);
            this.raziskovalci_panel.Location = new System.Drawing.Point(9, 25);
            this.raziskovalci_panel.Margin = new System.Windows.Forms.Padding(2);
            this.raziskovalci_panel.Name = "raziskovalci_panel";
            this.raziskovalci_panel.Size = new System.Drawing.Size(1028, 577);
            this.raziskovalci_panel.TabIndex = 17;
            // 
            // fakultete_panel
            // 
            this.fakultete_panel.Controls.Add(this.label9);
            this.fakultete_panel.Controls.Add(this.panel1);
            this.fakultete_panel.Controls.Add(this.fakultete_listView);
            this.fakultete_panel.Controls.Add(this.label8);
            this.fakultete_panel.Location = new System.Drawing.Point(9, 25);
            this.fakultete_panel.Margin = new System.Windows.Forms.Padding(2);
            this.fakultete_panel.Name = "fakultete_panel";
            this.fakultete_panel.Size = new System.Drawing.Size(1028, 577);
            this.fakultete_panel.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(548, 16);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(130, 26);
            this.label9.TabIndex = 0;
            this.label9.Text = "Informacije";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.Controls.Add(this.spletFakulteta);
            this.panel1.Controls.Add(this.emailFakulteta);
            this.panel1.Controls.Add(this.faksFakulteta);
            this.panel1.Controls.Add(this.telefonFakulteta);
            this.panel1.Controls.Add(this.naslovFakulteta);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.statusFakulteta);
            this.panel1.Controls.Add(this.odgovornaosebaFakulteta);
            this.panel1.Controls.Add(this.mestoFakulteta);
            this.panel1.Controls.Add(this.imeFakulteta);
            this.panel1.Location = new System.Drawing.Point(553, 45);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(467, 514);
            this.panel1.TabIndex = 5;
            // 
            // spletFakulteta
            // 
            this.spletFakulteta.AutoSize = true;
            this.spletFakulteta.Location = new System.Drawing.Point(33, 265);
            this.spletFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.spletFakulteta.Name = "spletFakulteta";
            this.spletFakulteta.Size = new System.Drawing.Size(73, 13);
            this.spletFakulteta.TabIndex = 10;
            this.spletFakulteta.Text = "spletFakulteta";
            // 
            // emailFakulteta
            // 
            this.emailFakulteta.AutoSize = true;
            this.emailFakulteta.Location = new System.Drawing.Point(33, 244);
            this.emailFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.emailFakulteta.Name = "emailFakulteta";
            this.emailFakulteta.Size = new System.Drawing.Size(75, 13);
            this.emailFakulteta.TabIndex = 9;
            this.emailFakulteta.Text = "emailFakulteta";
            // 
            // faksFakulteta
            // 
            this.faksFakulteta.AutoSize = true;
            this.faksFakulteta.Location = new System.Drawing.Point(33, 222);
            this.faksFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.faksFakulteta.Name = "faksFakulteta";
            this.faksFakulteta.Size = new System.Drawing.Size(71, 13);
            this.faksFakulteta.TabIndex = 8;
            this.faksFakulteta.Text = "faksFakulteta";
            // 
            // telefonFakulteta
            // 
            this.telefonFakulteta.AutoSize = true;
            this.telefonFakulteta.Location = new System.Drawing.Point(33, 200);
            this.telefonFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.telefonFakulteta.Name = "telefonFakulteta";
            this.telefonFakulteta.Size = new System.Drawing.Size(83, 13);
            this.telefonFakulteta.TabIndex = 7;
            this.telefonFakulteta.Text = "telefonFakulteta";
            // 
            // naslovFakulteta
            // 
            this.naslovFakulteta.AutoSize = true;
            this.naslovFakulteta.Location = new System.Drawing.Point(33, 178);
            this.naslovFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.naslovFakulteta.Name = "naslovFakulteta";
            this.naslovFakulteta.Size = new System.Drawing.Size(82, 13);
            this.naslovFakulteta.TabIndex = 6;
            this.naslovFakulteta.Text = "naslovFakulteta";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(23, 148);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "Kontakt:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(20, 21);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 20);
            this.label10.TabIndex = 4;
            this.label10.Text = "Osnovni podatki:";
            // 
            // statusFakulteta
            // 
            this.statusFakulteta.AutoSize = true;
            this.statusFakulteta.Location = new System.Drawing.Point(33, 115);
            this.statusFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.statusFakulteta.Name = "statusFakulteta";
            this.statusFakulteta.Size = new System.Drawing.Size(79, 13);
            this.statusFakulteta.TabIndex = 3;
            this.statusFakulteta.Text = "statusFakulteta";
            // 
            // odgovornaosebaFakulteta
            // 
            this.odgovornaosebaFakulteta.AutoSize = true;
            this.odgovornaosebaFakulteta.Location = new System.Drawing.Point(33, 97);
            this.odgovornaosebaFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.odgovornaosebaFakulteta.Name = "odgovornaosebaFakulteta";
            this.odgovornaosebaFakulteta.Size = new System.Drawing.Size(131, 13);
            this.odgovornaosebaFakulteta.TabIndex = 2;
            this.odgovornaosebaFakulteta.Text = "odgovornaosebaFakulteta";
            // 
            // mestoFakulteta
            // 
            this.mestoFakulteta.AutoSize = true;
            this.mestoFakulteta.Location = new System.Drawing.Point(33, 69);
            this.mestoFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mestoFakulteta.Name = "mestoFakulteta";
            this.mestoFakulteta.Size = new System.Drawing.Size(79, 13);
            this.mestoFakulteta.TabIndex = 1;
            this.mestoFakulteta.Text = "mestoFakulteta";
            // 
            // imeFakulteta
            // 
            this.imeFakulteta.AutoSize = true;
            this.imeFakulteta.Location = new System.Drawing.Point(33, 49);
            this.imeFakulteta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.imeFakulteta.Name = "imeFakulteta";
            this.imeFakulteta.Size = new System.Drawing.Size(67, 13);
            this.imeFakulteta.TabIndex = 0;
            this.imeFakulteta.Text = "imeFakulteta";
            // 
            // fakultete_listView
            // 
            this.fakultete_listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.imeFakultete});
            this.fakultete_listView.FullRowSelect = true;
            this.fakultete_listView.GridLines = true;
            this.fakultete_listView.Location = new System.Drawing.Point(16, 46);
            this.fakultete_listView.Margin = new System.Windows.Forms.Padding(2);
            this.fakultete_listView.Name = "fakultete_listView";
            this.fakultete_listView.Size = new System.Drawing.Size(500, 514);
            this.fakultete_listView.TabIndex = 4;
            this.fakultete_listView.UseCompatibleStateImageBehavior = false;
            this.fakultete_listView.View = System.Windows.Forms.View.Details;
            this.fakultete_listView.SelectedIndexChanged += new System.EventHandler(this.fakultete_listView_SelectedIndexChanged);
            // 
            // imeFakultete
            // 
            this.imeFakultete.Width = 500;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(11, 17);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(184, 26);
            this.label8.TabIndex = 2;
            this.label8.Text = "Seznam fakultet";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(847, 404);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(173, 41);
            this.button2.TabIndex = 16;
            this.button2.Text = "IZVOZI PODATKE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.fakultete_panel);
            this.Controls.Add(this.raziskovalci_panel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Scrapinator";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.raziskovalci_panel.ResumeLayout(false);
            this.raziskovalci_panel.PerformLayout();
            this.fakultete_panel.ResumeLayout(false);
            this.fakultete_panel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem raziskovalciToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fakulteteToolStripMenuItem;
        private System.Windows.Forms.ListView listRaziskovalcev;
        private System.Windows.Forms.ColumnHeader Evidencna_st;
        private System.Windows.Forms.ColumnHeader naziv;
        private System.Windows.Forms.ColumnHeader ime;
        private System.Windows.Forms.ColumnHeader priimek;
        private System.Windows.Forms.ColumnHeader raziskovalno_področje;
        private System.Windows.Forms.ColumnHeader status;
        private System.Windows.Forms.ColumnHeader rsrid;
        private System.Windows.Forms.TextBox naziv_textBox;
        private System.Windows.Forms.TextBox evidenca_textBox;
        private System.Windows.Forms.TextBox status_textBox;
        private System.Windows.Forms.TextBox raziskovalnoPodrocje_textBox;
        private System.Windows.Forms.TextBox priimek_textBox;
        private System.Windows.Forms.TextBox ime_textBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel raziskovalci_panel;
        private System.Windows.Forms.Panel fakultete_panel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListView fakultete_listView;
        private System.Windows.Forms.ColumnHeader imeFakultete;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label telefonFakulteta;
        private System.Windows.Forms.Label naslovFakulteta;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label statusFakulteta;
        private System.Windows.Forms.Label odgovornaosebaFakulteta;
        private System.Windows.Forms.Label mestoFakulteta;
        private System.Windows.Forms.Label imeFakulteta;
        private System.Windows.Forms.Label spletFakulteta;
        private System.Windows.Forms.Label emailFakulteta;
        private System.Windows.Forms.Label faksFakulteta;
        private System.Windows.Forms.Button button2;
    }
}

